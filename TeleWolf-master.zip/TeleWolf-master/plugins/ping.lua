do
 function run(msg, matches)
return [[ 😎آنلاینم عزیز و حواسم به گروه هست ]]
end
return {
patterns = {
"^انلاینی$",
"^[Pp]ing"
},
run = run
}
end